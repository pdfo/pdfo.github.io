This folder contains a modified version of Powell's COBYLA code. For the
original code, see pdfo/fsrc/original/cobyla.

***********************************************************************
Modified by:Tom M. RAGONNEAU (tom.ragonneau@connect.polyu.hk)
            and Zaikun ZHANG (zaikun.zhang@polyu.edu.hk)
            Department of Applied Mathematics,
            The Hong Kong Polytechnic University

Dedicated to late Professor M. J. D. Powell FRS (1936--2015).

We look forward to your feedback! Thank you very much!

March 2020, Hong Kong
***********************************************************************
